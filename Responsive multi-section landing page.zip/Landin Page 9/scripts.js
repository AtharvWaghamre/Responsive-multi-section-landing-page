
document.addEventListener("DOMContentLoaded", function() {

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            window.scrollTo({
                top: targetSection.offsetTop - 70, 
                behavior: 'smooth'
            });
        });
    });


    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });

    
    $('[data-toggle="tooltip"]').tooltip();

   
    $('.carousel').carousel({
        interval: 3000
    });

    
    const faqItems = document.querySelectorAll('.faq-item');
    faqItems.forEach(item => {
        const header = item.querySelector('.faq-header');
        header.addEventListener('click', function() {
            const content = item.querySelector('.faq-content');
            content.classList.toggle('active');
        });
    });
        document.getElementById("contactForm").addEventListener("submit", function(event) {
            event.preventDefault();
            let name = document.getElementById("name").value.trim();
            let email = document.getElementById("email").value.trim();
            let message = document.getElementById("message").value.trim();
            let formMessage = document.getElementById("formMessage");
            
            if (name === "" || email === "" || message === "") {
                formMessage.textContent = "All fields are required.";
                formMessage.style.color = "red";
                return;
            }
            
            let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,6}$/;
            if (!email.match(emailPattern)) {
                formMessage.textContent = "Please enter a valid email address.";
                formMessage.style.color = "red";
                return;
            }
            
            if (message.length < 10) {
                formMessage.textContent = "Message should be at least 10 characters long.";
                formMessage.style.color = "red";
                return;
            }
            
            formMessage.textContent = "Thank you! Your message has been sent.";
            formMessage.style.color = "green";
            document.getElementById("contactForm").reset();
        });
        function initMap() {
            var location = { lat: 40.7128, lng: -74.0060 }; 
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 14,
                center: location
            });
            var marker = new google.maps.Marker({
                position: location,
                map: map
            });
        }
    
        document.getElementById('contactForm').addEventListener('submit', function(event) {
            event.preventDefault();
            alert('Your message has been sent!');
            this.reset();
        });

    const newsletterForm = document.querySelector('#newsletter-form');
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const emailInput = newsletterForm.querySelector('input[type="email"]');
        if (emailInput.value) {
            alert('Thank you for subscribing!');
            emailInput.value = ''; 
        } else {
            alert('Please enter a valid email address.');
        }
    });
});
